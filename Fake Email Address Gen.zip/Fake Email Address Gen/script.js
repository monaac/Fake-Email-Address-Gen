document.getElementById('generate-button').addEventListener('click', function() {
    const country = document.getElementById('country-selector').value;
    const domain = document.getElementById('domain-selector').value;
    const emailAddresses = generateEmailAddresses(50000, country, domain);
    const emailAddressesContainer = document.getElementById('email-addresses');
    emailAddressesContainer.innerHTML = emailAddresses.join('<br>');
});

function generateEmailAddresses(count, country, domain) {
    const emailAddresses = [];
    for (let i = 0; i < count; i++) {
        emailAddresses.push(generateEmailAddress(country, domain));
    }
    return emailAddresses;
}

function generateEmailAddress(country, domain) {
    const randomString = Math.random().toString(36).substring(2, 15);
    return `${randomString}.${country}@${domain}`;
}

document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thank you for contacting us!');
    this.reset();
});
